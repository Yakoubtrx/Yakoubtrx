import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "12mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-6.2-astra";

const coachInstructions = `
أنت GOLD MASTER AI، مدرب عربي متخصص في تعليم تداول الذهب XAU/USD.
ملف المتعلم: مستوى متوسط، يستخدم MetaTrader 5، يفضّل Scalping، ورأس المال التدريبي المذكور 100 دولار.
اشرح بالعربية الواضحة وبشكل تعليمي ومنظم.
عند تحليل صورة شارت:
1) اذكر الإطار الزمني والسعر الظاهرين فقط إذا أمكن قراءتهما، وصرّح بما لا يمكن تأكيده.
2) حلّل بنية السوق والقمم والقيعان والدعم والمقاومة والزخم.
3) اعرض سيناريو صعود وسيناريو هبوط وسيناريو عدم التداول عند الحاجة.
4) لا تخترع أسعارًا حية أو أخبارًا أو بيانات غير موجودة في المدخلات.
5) ميّز بين الملاحظة والاستنتاج والافتراض.
6) لا تصف التحليل بأنه يقين ولا تضمن الربح.
7) لا تنفذ صفقات ولا تطلب بيانات دخول الوسيط أو كلمات المرور.
8) احسب المخاطر فقط إذا توفرت مواصفات العقد والمسافة إلى وقف الخسارة؛ لا تفترض حجم العقد أو قيمة النقطة.
9) ذكّر بأن حساب 100 دولار صغير وأن الحساب التجريبي مناسب للتدريب، وأن تكاليف السبريد والانزلاق قد تجعل السكالبينغ غير مناسب.
10) لا تعطِ إشارة شراء أو بيع كأمر؛ قدّم خطة مشروطة ومستويات تقريبية مع توضيح حدود الصورة.
أنت مدرب ومحلل تعليمي، ولست مستشارًا ماليًا.
`;

app.get("/health", (_req, res) => res.json({ ok: true, app: "GOLD MASTER AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "أضف OPENAI_API_KEY إلى ملف server/.env" });
    const { message, imageData } = req.body || {};
    if (!message && !imageData) return res.status(400).json({ error: "أرسل سؤالًا أو صورة." });

    const content = [];
    if (message) content.push({ type: "input_text", text: String(message).slice(0, 12000) });
    if (typeof imageData === "string" && imageData.startsWith("data:image/")) {
      content.push({ type: "input_image", image_url: imageData, detail: "high" });
    }

    const response = await client.responses.create({
      model,
      instructions: coachInstructions,
      input: [{ role: "user", content }]
    });

    res.json({ reply: response.output_text || "لم يصل رد نصي. حاول مرة أخرى." });
  } catch (error) {
    console.error("API request failed:", error?.message || error);
    res.status(500).json({ error: "تعذر إكمال التحليل. تحقق من إعدادات API والنموذج والاتصال." });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, "0.0.0.0", () => console.log(`GOLD MASTER AI server running on ${port}`));
