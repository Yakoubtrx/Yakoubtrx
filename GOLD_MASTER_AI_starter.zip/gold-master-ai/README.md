# GOLD MASTER AI — Starter MVP

واجهة واحدة تعمل على الويب وAndroid باستخدام Expo/React Native، مع خادم Node.js يحفظ مفتاح OpenAI بعيدًا عن التطبيق.

## المتطلبات
- Node.js 20+
- حساب OpenAI API مع الفوترة/الرصيد المفعّل حسب متطلبات حسابك
- هاتف Android عليه Expo Go للتجربة، أو Android Studio / EAS لبناء APK

## 1) تشغيل الخادم
```bash
cd server
cp .env.example .env
# افتح .env وضع مفتاح API في OPENAI_API_KEY
npm install
npm run dev
```
لا ترسل مفتاح API داخل المحادثة أو تضعه في تطبيق الهاتف أو مستودع Git.

## 2) تشغيل التطبيق
في نافذة طرفية ثانية:
```bash
npm install
npx expo start
```
- للويب: اضغط `w`
- لـ Android: امسح QR من Expo Go.
- عدّل `API_URL` في `app/index.tsx` إلى عنوان الخادم الذي يستطيع الهاتف الوصول إليه.
  - محاكي Android غالبًا يستخدم `http://10.0.2.2:8787`
  - هاتف حقيقي وخادم على نفس Wi-Fi: استخدم عنوان IP المحلي للكمبيوتر، مثل `http://192.168.1.20:8787`
  - لا تستخدم `localhost` من الهاتف.

## 3) الإعدادات
- نموذج API الافتراضي: `gpt-6.2-astra` عبر `OPENAI_MODEL` ويمكن تغييره إلى نموذج متاح في مشروعك.
- الخادم يقبل نصًا وصورة شارت اختيارية.
- التطبيق لا يرسل أو ينفذ أوامر تداول إلى MT5. التحليل تعليمي فقط.

## 4) تشغيل الويب
```bash
npx expo start --web
```

## 5) بناء Android
لإعداد EAS:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```
راجع `eas.json`. قد يتطلب بناء Android إعداد حساب Expo وتوقيع التطبيق.

## أمان قبل النشر العام
هذا إصدار تجريبي محلي. قبل نشره للناس أضف تسجيل دخول، حدود استخدام لكل مستخدم، حماية من الإساءة، سجلات آمنة، HTTPS، وسياسة خصوصية. لا تضع مفتاح OpenAI في تطبيق الويب أو Android.
