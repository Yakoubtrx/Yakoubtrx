import React, { useState } from "react";
import { SafeAreaView, View, Text, TextInput, Pressable, ScrollView, Image, ActivityIndicator, Platform, Alert } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { StatusBar } from "expo-status-bar";

const API_URL = "http://10.0.2.2:8787"; // غيّره إلى IP الكمبيوتر عند استخدام هاتف حقيقي

type Msg = { role: "user" | "assistant"; text: string; image?: string };

export default function Home() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", text: "مرحبًا بك في GOLD MASTER AI.\nأنا مدرّبك لتحليل الذهب XAU/USD، التحليل الفني والأساسي، والسكالبينغ وإدارة المخاطر.\nأرسل سؤالك أو صورة شارت من MT5. التحليل تعليمي وليس توصية مالية." }
  ]);
  const [input, setInput] = useState("");
  const [imageData, setImageData] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function chooseImage() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"], base64: true, quality: 0.75
    });
    if (!result.canceled && result.assets[0]?.base64) {
      setImageData(`data:image/jpeg;base64,${result.assets[0].base64}`);
    }
  }

  async function send() {
    if ((!input.trim() && !imageData) || busy) return;
    const userText = input.trim() || "حلّل صورة شارت الذهب المرفقة وفق منهج تدريبي.";
    const shownImage = imageData || undefined;
    setMessages(m => [...m, { role: "user", text: userText, image: shownImage }]);
    setInput("");
    setImageData(null);
    setBusy(true);
    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText, imageData: shownImage })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر الاتصال بالخادم");
      setMessages(m => [...m, { role: "assistant", text: data.reply }]);
    } catch (e: any) {
      setMessages(m => [...m, { role: "assistant", text: `حدث خطأ: ${e.message}\nتأكد أن الخادم يعمل وأن API_URL صحيح.` }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#090b10" }}>
      <StatusBar style="light" />
      <View style={{ padding: 18, borderBottomWidth: 1, borderColor: "#34302a" }}>
        <Text style={{ color: "#d9b45b", fontSize: 24, fontWeight: "800", letterSpacing: 1 }}>GOLD MASTER AI</Text>
        <Text style={{ color: "#b9b3a7", marginTop: 4 }}>مدرّب تداول الذهب • XAU/USD • MT5</Text>
      </View>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 14, gap: 12 }}>
        {messages.map((m, i) => (
          <View key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "92%", backgroundColor: m.role === "user" ? "#28251e" : "#171b24", borderColor: m.role === "user" ? "#786338" : "#343b49", borderWidth: 1, borderRadius: 14, padding: 12 }}>
            <Text style={{ color: m.role === "user" ? "#f4d68b" : "#e9eaf0", lineHeight: 23 }}>{m.text}</Text>
            {m.image ? <Image source={{ uri: m.image }} style={{ width: 240, height: 160, marginTop: 8, borderRadius: 8 }} resizeMode="contain" /> : null}
          </View>
        ))}
        {busy ? <ActivityIndicator color="#d9b45b" /> : null}
      </ScrollView>
      {imageData ? <View style={{ paddingHorizontal: 14 }}><Text style={{ color: "#e9ce8a" }}>تم اختيار صورة للشارت ✓</Text></View> : null}
      <View style={{ padding: 12, borderTopWidth: 1, borderColor: "#34302a", gap: 9 }}>
        <TextInput value={input} onChangeText={setInput} placeholder="اسأل مدرب الذهب..." placeholderTextColor="#888" multiline style={{ color: "white", backgroundColor: "#171b24", borderRadius: 12, padding: 12, minHeight: 48, maxHeight: 110, textAlign: "right" }} />
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={chooseImage} style={{ backgroundColor: "#29251c", padding: 12, borderRadius: 10 }}><Text style={{ color: "#e9ce8a" }}>إرفاق شارت</Text></Pressable>
          <Pressable onPress={send} disabled={busy} style={{ flex: 1, backgroundColor: busy ? "#665b43" : "#b38b3e", padding: 12, borderRadius: 10, alignItems: "center" }}><Text style={{ color: "#111", fontWeight: "800" }}>{busy ? "جارٍ التحليل..." : "إرسال"}</Text></Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}
